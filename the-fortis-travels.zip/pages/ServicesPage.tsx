
import React from 'react';
import { Plane, Hotel, ShieldCheck, Map, Briefcase, Gift, Compass, Users, Globe, Award, Sparkles, CreditCard } from 'lucide-react';
import { Link } from 'react-router-dom';

const ServicesPage: React.FC = () => {
  const corePillars = [
    {
      title: "Bespoke Travel Design",
      subtitle: "Tailored to your unique rhythm",
      image: "https://images.unsplash.com/photo-1534073828943-f801091bb18c?auto=format&fit=crop&q=80&w=1200",
      description: "We don't just book trips; we architect experiences. From private island escapes to hidden cultural immersions, every itinerary is a unique masterpiece reflecting your personal style.",
      features: ["Private Villa & Chalet Rentals", "Exclusive Access to Sold-out Events", "Curated Michelin-star Dining Tours", "Private Heritage & Art Guides"]
    },
    {
      title: "Corporate Excellence",
      subtitle: "Precision for the modern executive",
      image: "https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?auto=format&fit=crop&q=80&w=1200",
      description: "Managing the complex logistics of global business travel with military precision. We ensure that you and your team are productive, rested, and always on time.",
      features: ["24/7 VIP Travel Support", "MICE Event Management", "Complex Route Optimization", "Executive Ground Logistics"]
    }
  ];

  const specializedServices = [
    {
      icon: <Globe className="text-yellow-500" size={24} />,
      title: "Visa & Entry Formalities",
      desc: "Streamlined processing for global entries, ensuring all regulatory requirements are met with ease."
    },
    {
      icon: <Award className="text-yellow-500" size={24} />,
      title: "Luxury Insurance",
      desc: "Comprehensive coverage tailored for high-value travelers, including specialized asset protection."
    },
    {
      icon: <Sparkles className="text-yellow-500" size={24} />,
      title: "Lifestyle Concierge",
      desc: "Personal shopping, event ticketing, and errand services managed by our dedicated lifestyle agents."
    },
    {
      icon: <Users className="text-yellow-500" size={24} />,
      title: "Group Delegations",
      desc: "Full-scale management for large groups, diplomatic missions, and sports teams."
    }
  ];

  return (
    <div className="bg-black">
      {/* Editorial Header */}
      <section className="relative py-32 border-b border-yellow-900/20 overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full gold-gradient opacity-5 blur-[120px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <span className="text-yellow-500 font-bold uppercase tracking-[0.4em] text-xs mb-4 block">Our Portfolio</span>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8 leading-tight">
              Bespoke Services <br />
              <span className="gold-text-gradient italic">Without Compromise</span>
            </h1>
            <p className="text-xl text-gray-400 font-light leading-relaxed">
              The Fortis Travels provides an ecosystem of luxury. Our services are designed for individuals and organizations who demand discretion, speed, and absolute perfection.
            </p>
          </div>
        </div>
      </section>

      {/* Main Pillars - Alternating Layout */}
      <section className="py-24 space-y-32">
        {corePillars.map((pillar, i) => (
          <div key={i} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className={`flex flex-col ${i % 2 !== 0 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-16 items-center`}>
              <div className="flex-1 w-full">
                <div className="relative group overflow-hidden rounded-[2.5rem] border border-yellow-900/30">
                  <img 
                    src={pillar.image} 
                    alt={pillar.title} 
                    className="w-full h-[600px] object-cover transition-transform duration-1000 group-hover:scale-110 grayscale hover:grayscale-0" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
                </div>
              </div>
              <div className="flex-1 space-y-8">
                <div>
                  <h4 className="text-yellow-500 font-bold uppercase tracking-widest text-xs mb-2">{pillar.subtitle}</h4>
                  <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">{pillar.title}</h2>
                </div>
                <p className="text-gray-400 text-lg font-light leading-relaxed">
                  {pillar.description}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                  {pillar.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="h-1.5 w-1.5 rounded-full gold-gradient"></div>
                      <span className="text-gray-300 text-sm font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-6">
                  <Link to="/contact" className="inline-flex items-center gap-4 text-yellow-500 font-bold uppercase tracking-[0.2em] text-xs group">
                    <span className="border-b border-transparent group-hover:border-yellow-500 transition-all pb-1">Start Your Journey</span>
                    <div className="p-3 border border-yellow-500/30 rounded-full group-hover:bg-yellow-500 group-hover:text-black transition-all">
                      <Compass size={20} />
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Beyond Travel - Specialized Grid */}
      <section className="py-24 bg-zinc-950/50 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-serif font-bold text-white mb-4">Ancillary Excellence</h2>
            <p className="text-gray-500 uppercase tracking-widest text-xs">The details that define the difference</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {specializedServices.map((service, i) => (
              <div key={i} className="p-8 border border-yellow-900/10 bg-black hover:border-yellow-500/40 transition-all rounded-3xl group">
                <div className="mb-6 transform group-hover:-translate-y-2 transition-transform duration-300">{service.icon}</div>
                <h3 className="text-white font-bold mb-3 text-sm uppercase tracking-widest">{service.title}</h3>
                <p className="text-gray-500 text-xs leading-relaxed">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* The Fortis Circle - Membership Concept */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-zinc-900 to-black border border-yellow-900/30 rounded-[3rem] p-12 md:p-24 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 gold-gradient opacity-5 blur-[100px] -mr-48 -mt-48"></div>
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-yellow-500 font-bold uppercase tracking-[0.4em] text-xs mb-4">Invitation Only</h2>
                <h3 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">The Fortis Circle Membership</h3>
                <p className="text-gray-400 mb-8 font-light">
                  Join an elite group of travelers who enjoy preferential rates, complimentary upgrades, and a dedicated personal lifestyle manager available 24 hours a day, anywhere in the world.
                </p>
                <div className="space-y-4 mb-10">
                  <div className="flex items-center gap-4 text-gray-300">
                    <Award size={20} className="text-yellow-500" />
                    <span className="text-sm">Priority Booking on High-Demand Properties</span>
                  </div>
                  <div className="flex items-center gap-4 text-gray-300">
                    <Award size={20} className="text-yellow-500" />
                    <span className="text-sm">Zero Transaction Fees on Foreign Bookings</span>
                  </div>
                </div>
                <Link to="/contact" className="btn-gold px-12 py-5 rounded-full inline-block font-bold">Apply for Membership</Link>
              </div>
              <div className="hidden lg:block">
                <div className="relative aspect-square">
                  <div className="absolute inset-0 border-[20px] border-yellow-500/10 rounded-full animate-pulse"></div>
                  <div className="absolute inset-10 border-[1px] border-yellow-500/30 rounded-full flex items-center justify-center">
                    <div className="text-center">
                      <span className="gold-text-gradient text-8xl font-serif font-bold italic">F</span>
                      <p className="text-yellow-500 text-[10px] tracking-[0.5em] mt-4 uppercase font-bold">The Fortis Elite</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment CTA */}
      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="gold-gradient p-1 rounded-[3.5rem]">
            <div className="bg-black rounded-[3.4rem] p-12 text-center py-20">
              <div className="mb-8 flex justify-center">
                <div className="p-5 bg-yellow-500 rounded-full text-black">
                  <CreditCard size={32} />
                </div>
              </div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">Seamless Secure Payments</h2>
              <p className="text-gray-400 mb-10 max-w-xl mx-auto font-light leading-relaxed">
                Experience hassle-free transactions through our encrypted payment gateway. Secure your premium bookings instantly from any corner of the globe.
              </p>
              <Link to="/payment" className="bg-white text-black hover:bg-yellow-500 transition-colors px-12 py-5 rounded-full font-bold uppercase tracking-widest text-sm inline-block">
                Secure Online Payment
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;
