
import React from 'react';
import { Globe, ShieldCheck, Clock, FileCheck, CheckCircle2, Phone, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const visaTypes = [
  {
    title: "30-Day Tourist Visa",
    subtitle: "Single Entry",
    price: "299",
    features: ["48-Hour Processing", "Easy Online Submission", "Minimal Documentation", "Stay up to 30 Days"]
  },
  {
    title: "60-Day Tourist Visa",
    subtitle: "Single Entry",
    price: "549",
    features: ["Express Processing", "Extendable Option", "Valid for All UAE Airports", "Stay up to 60 Days"]
  },
  {
    title: "Multi-Country Support",
    subtitle: "Global Assistance",
    price: "450",
    features: ["Schengen Specialist", "USA & UK Assistance", "Document Translation", "Appointment Scheduling"]
  }
];

const VisasPage: React.FC = () => {
  return (
    <div className="bg-black min-h-screen pt-12">
      <section className="relative py-24 border-b border-yellow-900/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="max-w-2xl">
              <span className="text-yellow-500 font-bold uppercase tracking-[0.4em] text-xs mb-4 block">Official Partner</span>
              <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">Fast-Track <br /><span className="gold-text-gradient italic">Visa Services</span></h1>
              <p className="text-gray-400 text-lg font-light leading-relaxed mb-10">
                Obtain your UAE tourist visa or global travel permits with absolute speed and professional precision. Based in Dubai South, we handle all immigration complexities for you.
              </p>
              <div className="flex gap-4">
                <Link to="/contact" className="btn-gold px-10 py-4 rounded-full text-[10px] uppercase tracking-widest">Apply Now</Link>
                <Link to="/contact" className="border border-yellow-500/30 text-yellow-500 px-10 py-4 rounded-full text-[10px] uppercase tracking-widest hover:bg-yellow-500/5">Inquire Global</Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative p-12 bg-zinc-950 rounded-[3rem] border border-yellow-900/20 shadow-2xl">
                <Globe size={120} className="text-yellow-500/10 absolute -top-10 -right-10" />
                <div className="space-y-8">
                  <div className="flex items-center gap-6">
                    <div className="w-12 h-12 bg-yellow-500 rounded-2xl flex items-center justify-center text-black shadow-lg shadow-yellow-500/20"><ShieldCheck size={24} /></div>
                    <div>
                      <p className="text-white font-bold uppercase tracking-widest text-xs">Certified Agent</p>
                      <p className="text-gray-500 text-[10px]">Dubai South Immigration Partner</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="w-12 h-12 bg-yellow-500 rounded-2xl flex items-center justify-center text-black shadow-lg shadow-yellow-500/20"><Clock size={24} /></div>
                    <div>
                      <p className="text-white font-bold uppercase tracking-widest text-xs">Express Delivery</p>
                      <p className="text-gray-500 text-[10px]">Most visas issued within 24-48 hours</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="w-12 h-12 bg-yellow-500 rounded-2xl flex items-center justify-center text-black shadow-lg shadow-yellow-500/20"><FileCheck size={24} /></div>
                    <div>
                      <p className="text-white font-bold uppercase tracking-widest text-xs">Zero Risk</p>
                      <p className="text-gray-500 text-[10px]">99.8% Success rate for UAE entries</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-zinc-950/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {visaTypes.map((visa, i) => (
              <div key={i} className="bg-black p-12 rounded-[3rem] border border-yellow-900/10 hover:border-yellow-500/40 transition-all flex flex-col">
                <span className="text-yellow-500 text-[10px] font-black uppercase tracking-[0.3em] mb-4">{visa.subtitle}</span>
                <h3 className="text-3xl font-serif font-bold text-white mb-8">{visa.title}</h3>
                <div className="mb-10 flex items-baseline gap-2">
                  <span className="text-xs text-gray-500 uppercase font-black">Starting at</span>
                  <span className="text-4xl font-bold gold-text-gradient">AED {visa.price}</span>
                </div>
                <ul className="space-y-4 mb-12 flex-grow">
                  {visa.features.map((f, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-gray-400 text-xs font-light">
                      <CheckCircle2 size={14} className="text-yellow-600" /> {f}
                    </li>
                  ))}
                </ul>
                <Link to="/contact" className="w-full text-center py-4 bg-zinc-900 hover:bg-yellow-500 hover:text-black text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">Select Plan</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-black">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="bg-zinc-950 p-16 rounded-[4rem] border border-yellow-900/10">
            <h2 className="text-4xl font-serif font-bold mb-8">Need <span className="gold-text-gradient italic">Expert Help?</span></h2>
            <p className="text-gray-400 mb-12 text-lg font-light">
              Our visa consultants are available via phone and WhatsApp to walk you through the entire process.
            </p>
            <div className="flex flex-col md:flex-row justify-center gap-8">
              <a href="tel:+971566286377" className="flex items-center justify-center gap-4 text-white font-bold uppercase tracking-widest text-xs hover:text-yellow-500 transition-colors">
                <Phone size={20} className="text-yellow-500" /> +971 56 628 6377
              </a>
              <Link to="/contact" className="btn-gold px-12 py-5 rounded-full text-[10px] uppercase tracking-widest flex items-center gap-2 mx-auto md:mx-0">
                Contact Support <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default VisasPage;
