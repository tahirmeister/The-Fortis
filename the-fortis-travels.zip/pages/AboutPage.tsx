
import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="bg-black py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-yellow-500 font-bold uppercase tracking-[0.4em] mb-4 text-sm">The Heritage</h2>
            <h1 className="text-5xl font-serif font-bold text-white mb-8 leading-tight">
              Crafting Legacy in <br />
              <span className="gold-text-gradient">Travel & Lifestyle</span>
            </h1>
            <div className="space-y-6 text-gray-300 leading-relaxed font-light">
              <p>
                Based in the dynamic hub of Dubai South Freezone, THE FORTIS TRAVELS has emerged as a beacon of excellence in the global travel industry. We specialize in providing a seamless blend of traditional hospitality and modern efficiency.
              </p>
              <p>
                Our philosophy is simple: perfection is in the details. Whether it's a corporate mission, a private getaway, or bespoke lifestyle management, our team works around the clock to ensure every aspect of your journey exceeds expectations.
              </p>
              <div className="grid grid-cols-2 gap-8 pt-6">
                <div>
                  <h4 className="text-3xl font-serif font-bold gold-text-gradient mb-2">15+</h4>
                  <p className="text-xs uppercase tracking-widest text-gray-500">Years Experience</p>
                </div>
                <div>
                  <h4 className="text-3xl font-serif font-bold gold-text-gradient mb-2">200+</h4>
                  <p className="text-xs uppercase tracking-widest text-gray-500">Global Partners</p>
                </div>
              </div>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="absolute -inset-4 border border-yellow-500/20 rounded-3xl"></div>
              <img 
                src="https://images.unsplash.com/photo-1574944966950-8164c21fe5ef?auto=format&fit=crop&q=80&w=1200" 
                alt="Luxury Concierge Service" 
                className="relative rounded-3xl w-full h-[500px] object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute -bottom-6 -left-6 bg-zinc-950 p-8 rounded-2xl border border-yellow-900/30">
                <p className="text-yellow-500 italic font-serif text-lg">"Excellence is not an act, but a habit."</p>
              </div>
            </div>
          </div>
        </div>

        <section className="mt-40 text-center">
          <h2 className="text-3xl font-serif font-bold text-white mb-16">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {['Integrity', 'Discretion', 'Innovation', 'Excellence'].map((value, i) => (
              <div key={i} className="p-10 border border-yellow-900/20 bg-zinc-950 rounded-2xl">
                <h3 className="text-yellow-500 font-bold text-lg mb-2">{value}</h3>
                <div className="h-0.5 w-12 gold-gradient mx-auto"></div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;
