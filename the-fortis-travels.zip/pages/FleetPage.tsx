
import React from 'react';
import { Plane, Ship, Car, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const fleetCategories = [
  {
    title: "Private Aviation",
    icon: <Plane size={40} />,
    image: "https://images.unsplash.com/photo-1540962351504-03099e0a754b?auto=format&fit=crop&q=80&w=800",
    features: ["Global Reach", "VIP Terminal Access", "Customized In-flight Catering", "Ultra-Long-Range Jets"]
  },
  {
    title: "Luxury Yacht Charter",
    icon: <Ship size={40} />,
    image: "https://images.unsplash.com/photo-1605281317010-fe5ffe798156?auto=format&fit=crop&q=80&w=800",
    features: ["Mediterranean & Caribbean", "Full Professional Crew", "On-board Lifestyle Chefs", "Watersports Equipment"]
  },
  {
    title: "Elite Chauffeur",
    icon: <Car size={40} />,
    image: "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=800",
    features: ["Rolls Royce & Maybach", "Professional Security Detail", "Airport Transfers", "24/7 Availability"]
  }
];

const FleetPage: React.FC = () => {
  return (
    <div className="bg-black py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <h2 className="text-yellow-500 font-bold uppercase tracking-[0.4em] mb-4 text-xs">The Fortis Fleet</h2>
          <h1 className="text-5xl font-serif font-bold text-white mb-6">Transport Excellence</h1>
          <p className="text-gray-400 max-w-2xl mx-auto font-light text-lg">
            Movement defined by sophistication. Access our premier selection of private transport assets for land, sea, and air.
          </p>
        </div>

        <div className="space-y-32">
          {fleetCategories.map((item, i) => (
            <div key={i} className={`flex flex-col ${i % 2 !== 0 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-16 items-center`}>
              <div className="flex-1 relative group">
                <div className="absolute -inset-4 gold-gradient opacity-10 blur-2xl rounded-3xl group-hover:opacity-20 transition-opacity"></div>
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="relative rounded-3xl w-full h-[450px] object-cover border border-yellow-900/20"
                />
              </div>
              <div className="flex-1 space-y-8">
                <div className="text-yellow-500">{item.icon}</div>
                <h2 className="text-4xl font-serif font-bold text-white uppercase tracking-tight">{item.title}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {item.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-3 text-gray-400">
                      <CheckCircle2 size={16} className="text-yellow-500" />
                      <span className="text-sm font-light">{feature}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-8">
                  <Link to="/contact" className="btn-gold px-10 py-4 rounded-full inline-block">
                    Inquire Availability
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FleetPage;
