
import React from 'react';
import { useLocation } from 'react-router-dom';
import { CreditCard, Lock, ShieldCheck, CheckCircle2, ChevronRight, Globe, Info, Calendar, MapPin, Tag } from 'lucide-react';

const PaymentPage: React.FC = () => {
  const location = useLocation();
  const bookingDetails = location.state as {
    itemTitle?: string;
    location?: string;
    date?: string;
    price?: string;
    type?: string;
  } | null;

  return (
    <div className="bg-black pt-32 pb-24 min-h-screen flex items-center">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Payment Form */}
          <div className="flex-grow">
            <div className="bg-zinc-950 border border-yellow-900/20 rounded-[3rem] overflow-hidden shadow-2xl">
              <div className="gold-gradient p-12 text-center text-black">
                <h1 className="text-4xl font-serif font-bold mb-4 tracking-tighter">Secure Checkout</h1>
                <div className="flex items-center justify-center gap-2 opacity-70 font-black uppercase tracking-[0.3em] text-[10px]">
                  <Lock size={12} /> Global Encryption Verified
                </div>
              </div>

              {/* Dynamic Booking Summary */}
              {bookingDetails && (
                <div className="p-10 md:p-12 border-b border-yellow-900/10 bg-yellow-500/5">
                  <h2 className="text-yellow-500 font-black uppercase tracking-[0.3em] text-[11px] mb-8 flex items-center gap-3">
                    <Info size={16} /> Verified Booking Summary
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    <div className="space-y-2">
                      <p className="text-[9px] text-gray-500 uppercase font-black">Item Selection</p>
                      <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-tight">
                        <Tag size={14} className="text-yellow-500" /> {bookingDetails.itemTitle || 'Custom Package'}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-[9px] text-gray-500 uppercase font-black">Destination</p>
                      <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-tight">
                        <MapPin size={14} className="text-yellow-500" /> {bookingDetails.location || 'Dubai, UAE'}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-[9px] text-gray-500 uppercase font-black">Date</p>
                      <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-tight">
                        <Calendar size={14} className="text-yellow-500" /> {bookingDetails.date || 'TBD'}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-[9px] text-gray-500 uppercase font-black">Service Category</p>
                      <div className="inline-block px-3 py-1 bg-yellow-500 text-black text-[9px] font-black uppercase rounded-full">
                        {bookingDetails.type || 'LUXURY TRAVEL'}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="p-10 md:p-16">
                <form className="space-y-10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="space-y-4">
                      <label className="block text-gray-500 text-[9px] uppercase tracking-widest font-black ml-1">Reference Number</label>
                      <input type="text" className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500 transition-all font-bold" defaultValue={bookingDetails ? `TF-${Math.random().toString(36).substr(2, 9).toUpperCase()}` : "TF-ORD-XXXXX"} />
                    </div>
                    <div className="space-y-4">
                      <label className="block text-gray-500 text-[9px] uppercase tracking-widest font-black ml-1">Total Amount (AED)</label>
                      <div className="relative">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 text-yellow-500 font-black">AED</span>
                        <input type="number" className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-16 pr-6 text-white focus:outline-none focus:border-yellow-500 transition-all font-black text-xl" defaultValue={bookingDetails?.price || "0.00"} />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-white font-bold text-xs uppercase tracking-widest flex items-center gap-3">
                        <CreditCard className="text-yellow-500" size={18} /> Card Information
                      </h3>
                      <div className="flex gap-2">
                         <div className="w-10 h-6 bg-zinc-900 border border-zinc-800 rounded flex items-center justify-center text-[8px] text-gray-500">VISA</div>
                         <div className="w-10 h-6 bg-zinc-900 border border-zinc-800 rounded flex items-center justify-center text-[8px] text-gray-500">MC</div>
                         <div className="w-10 h-6 bg-zinc-900 border border-zinc-800 rounded flex items-center justify-center text-[8px] text-gray-500">AMEX</div>
                      </div>
                    </div>
                    <div className="space-y-6 bg-black/40 p-8 rounded-3xl border border-yellow-900/10">
                      <input required type="text" className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500" placeholder="Cardholder Name" />
                      <div className="relative">
                        <input required type="text" className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500" placeholder="Card Number (0000 0000 0000 0000)" />
                        <CreditCard size={18} className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-700" />
                      </div>
                      <div className="grid grid-cols-2 gap-6">
                        <input required type="text" className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500" placeholder="MM/YY" />
                        <input required type="text" className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500" placeholder="CVV" />
                      </div>
                    </div>
                  </div>

                  <button type="submit" className="w-full btn-gold py-6 rounded-2xl text-sm font-black uppercase tracking-[0.4em] mt-10 shadow-2xl shadow-yellow-500/10 flex items-center justify-center gap-4 group">
                    Authorize Payment <ChevronRight className="group-hover:translate-x-2 transition-transform" />
                  </button>
                  
                  <div className="flex items-center justify-center gap-6 pt-10 border-t border-yellow-900/10 grayscale opacity-30">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-4" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-6" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-4" />
                  </div>
                </form>
              </div>
            </div>
          </div>

          {/* Sidebar / Info */}
          <div className="w-full lg:w-[380px] space-y-8">
            <div className="bg-zinc-950 p-10 rounded-[2.5rem] border border-yellow-900/10 shadow-xl">
              <h4 className="text-yellow-500 font-black mb-8 uppercase tracking-[0.2em] text-[10px]">Payment Guarantee</h4>
              <ul className="space-y-6">
                {[
                  "SSL Certified Encryption",
                  "Direct Bank Authorization",
                  "Instant Transaction SMS",
                  "Fraud Protection Enabled",
                  "24/7 Dispute Resolution"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-4 text-gray-300 text-xs font-bold uppercase tracking-wider">
                    <CheckCircle2 size={16} className="text-yellow-500 flex-shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-10 bg-yellow-500/5 border border-yellow-500/20 rounded-[2.5rem] text-center">
              <ShieldCheck className="text-yellow-500 mx-auto mb-6" size={48} />
              <p className="text-white font-bold uppercase tracking-[0.2em] text-xs mb-2">Verified Merchant</p>
              <p className="text-gray-500 text-[9px] uppercase font-black">The Fortis Travels LLC</p>
              <p className="text-gray-500 text-[9px] uppercase font-black mt-1">Dubai South Freezone</p>
            </div>
            
            <div className="flex flex-col items-center gap-4 text-center">
              <Globe className="text-yellow-500/30" size={32} />
              <p className="text-gray-600 text-[10px] font-bold uppercase leading-relaxed px-10">
                Your transaction will be processed in AED. Exchange rates may vary depending on your bank.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
