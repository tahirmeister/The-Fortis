
import React from 'react';
import { Phone, Mail, MapPin, MessageSquare, Clock } from 'lucide-react';

const ContactPage: React.FC = () => {
  const contactInfo = [
    {
      icon: <MapPin className="text-yellow-500" size={24} />,
      title: "Head Office Address",
      details: ["THE FORTIS TRAVELS", "DUBAI SOUTH FREEZONE", "DUBAI-UNITED ARAB EMIRATES"]
    },
    {
      icon: <Phone className="text-yellow-500" size={24} />,
      title: "Central Booking",
      details: ["+971 56 628 6377"]
    },
    {
      icon: <MessageSquare className="text-yellow-500" size={24} />,
      title: "24/7 WhatsApp",
      details: ["+971 56 628 6377"]
    },
    {
      icon: <Mail className="text-yellow-500" size={24} />,
      title: "Email Support",
      details: ["OPS@THEFORTISNY.COM"]
    }
  ];

  return (
    <div className="bg-black pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <span className="text-yellow-500 text-xs font-black uppercase tracking-[0.4em] mb-4 block">Get In Touch</span>
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">Reach <span className="gold-text-gradient italic">The Fortis</span></h1>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light leading-relaxed">
            Whether you are planning a corporate trip or a private getaway, our dedicated agents are standing by to assist you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-1 space-y-8">
            {contactInfo.map((item, i) => (
              <div key={i} className="flex gap-8 p-10 border border-yellow-900/10 bg-zinc-950 rounded-[2rem] hover:border-yellow-500/20 transition-all group">
                <div className="flex-shrink-0 bg-black p-4 rounded-2xl text-yellow-500 group-hover:scale-110 transition-transform">{item.icon}</div>
                <div>
                  <h4 className="text-white font-bold text-[10px] uppercase tracking-widest mb-4 opacity-50">{item.title}</h4>
                  {item.details.map((line, idx) => (
                    <p key={idx} className="text-white font-bold text-sm tracking-tight">{line}</p>
                  ))}
                </div>
              </div>
            ))}
            
            <div className="p-10 border border-yellow-500/10 bg-yellow-500/5 rounded-[2rem] flex items-center gap-6">
              <Clock className="text-yellow-500" size={32} />
              <div>
                <p className="text-white font-bold text-xs uppercase tracking-widest">Global Support</p>
                <p className="text-gray-500 text-xs mt-1">Available 24/7/365</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-zinc-950 p-12 md:p-16 rounded-[3rem] border border-yellow-900/10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 gold-gradient"></div>
              <h3 className="text-3xl font-serif font-bold text-white mb-10">Direct Message</h3>
              <form className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <label className="block text-gray-500 text-[9px] uppercase tracking-widest mb-3 font-black">Full Name</label>
                    <input type="text" className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500 transition-all" placeholder="Enter name" />
                  </div>
                  <div>
                    <label className="block text-gray-500 text-[9px] uppercase tracking-widest mb-3 font-black">Email Address</label>
                    <input type="email" className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500 transition-all" placeholder="Enter email" />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-500 text-[9px] uppercase tracking-widest mb-3 font-black">Inquiry Type</label>
                  <select className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500 transition-all font-bold appearance-none">
                    <option>Tourist Visa Inquiry</option>
                    <option>Corporate Tour Package</option>
                    <option>Luxury Car Transfer</option>
                    <option>Private Yacht Charter</option>
                    <option>Others</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-500 text-[9px] uppercase tracking-widest mb-3 font-black">Message Body</label>
                  <textarea rows={5} className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-yellow-500 transition-all" placeholder="Briefly describe your requirements..."></textarea>
                </div>
                <button type="submit" className="w-full btn-gold py-5 rounded-2xl text-[11px] font-black uppercase tracking-[0.3em] shadow-2xl shadow-yellow-500/10">
                  Submit Inquiry
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
