
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Globe, 
  Shield, 
  Plane, 
  Users, 
  Search,
  Hotel,
  Calendar,
  ChevronRight,
  MapPin,
  Clock3,
  Loader2,
  ChevronLeft,
  Briefcase,
  Headphones,
  Plus,
  Minus
} from 'lucide-react';

const heroImages = [
  "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1506461883276-594a12b11cf3?auto=format&fit=crop&q=80&w=2000"
];

const globalCities = [
  "Dubai, UAE (DXB)", "Abu Dhabi, UAE (AUH)", "London, UK (LHR)", "Paris, France (CDG)", "Tokyo, Japan (NRT)", "Singapore (SIN)", "New York, USA (JFK)",
  "Doha, Qatar (DOH)", "Riyadh, Saudi Arabia (RUH)", "Istanbul, Turkey (IST)", "Zurich, Switzerland (ZRH)", "Sydney, Australia (SYD)"
];

const bookingCategories: Record<string, string[]> = {
  flights: ["Economy Class", "Premium Economy", "Business Class", "First Class"],
  hotels: ["Luxury Resorts", "Boutique Hotels", "Desert Retreats", "Private Villas"]
};

const trendingDestinations = [
  { name: "Maldives", img: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&q=80&w=600", price: "4,500" },
  { name: "Switzerland", img: "https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&q=80&w=600", price: "6,200" },
  { name: "Japan", img: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80&w=600", price: "5,800" },
  { name: "Turkey", img: "https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?auto=format&fit=crop&q=80&w=600", price: "2,900" }
];

const HomePage: React.FC = () => {
  const [currentHero, setCurrentHero] = useState(0);
  const [activeTab, setActiveTab] = useState('flights');
  const [isSearching, setIsSearching] = useState(false);
  const [showTravellerDropdown, setShowTravellerDropdown] = useState(false);
  
  const [flightConfig, setFlightConfig] = useState({
    tripType: 'Return',
    origin: '',
    destination: '',
    departureDate: '',
    returnDate: '',
    travellers: { adults: 1, children: 0, infants: 0 },
    cabin: 'Economy Class'
  });

  const [searchData, setSearchData] = useState({
    destination: '',
    category: bookingCategories['flights'][0],
    date: ''
  });
  
  const navigate = useNavigate();

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHero((prev) => (prev + 1) % heroImages.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const handleBookingSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      const targetPath = activeTab === 'flights' ? '/flights' : '/payment';
      navigate(targetPath, { 
        state: { 
          itemTitle: activeTab === 'flights' ? `${flightConfig.tripType} Flight` : searchData.category,
          location: activeTab === 'flights' ? `${flightConfig.origin} to ${flightConfig.destination}` : searchData.destination,
          date: activeTab === 'flights' ? flightConfig.departureDate : searchData.date,
          type: activeTab.toUpperCase(),
          price: '850',
          flightDetails: activeTab === 'flights' ? flightConfig : null
        } 
      });
    }, 2500);
  };

  const updateTravellers = (type: 'adults' | 'children' | 'infants', op: 'add' | 'sub') => {
    setFlightConfig(prev => ({
      ...prev,
      travellers: {
        ...prev.travellers,
        [type]: op === 'add' ? prev.travellers[type] + 1 : Math.max(type === 'adults' ? 1 : 0, prev.travellers[type] - 1)
      }
    }));
  };

  const totalTravellers = flightConfig.travellers.adults + flightConfig.travellers.children + flightConfig.travellers.infants;

  return (
    <div className="bg-black text-white relative">
      {isSearching && (
        <div className="fixed inset-0 z-[200] bg-black/98 flex flex-col items-center justify-center">
          <div className="relative w-32 h-32 mb-10">
            <Loader2 className="w-full h-full text-yellow-500 animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center font-serif text-3xl gold-text-gradient font-bold">F</div>
          </div>
          <h2 className="text-3xl font-serif font-bold gold-text-gradient mb-3">Checking Live Inventory</h2>
          <p className="text-gray-500 text-xs uppercase tracking-[0.5em] font-black">Syncing with global distribution systems...</p>
        </div>
      )}

      <section className="relative h-[95vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          {heroImages.map((img, idx) => (
            <div key={img} className={`absolute inset-0 transition-opacity duration-1500 ${idx === currentHero ? 'opacity-70 scale-100' : 'opacity-0 scale-105'}`}>
              <img src={img} alt="Luxury Travel" className="w-full h-full object-cover" />
            </div>
          ))}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black/40"></div>
        </div>

        <div className="relative z-10 w-full max-w-[1440px] mx-auto px-4 mt-12">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-8xl font-serif font-bold mb-6 tracking-tight leading-tight">
              Premium Travel <br /><span className="gold-text-gradient italic">Without Boundaries</span>
            </h1>
            <p className="text-gray-300 text-sm md:text-lg font-bold tracking-[0.3em] uppercase opacity-80">The Preferred Portal for Global Nomads</p>
          </div>

          <div className="max-w-6xl mx-auto">
            <div className="bg-zinc-950/90 backdrop-blur-3xl rounded-[2.5rem] border border-yellow-900/30 shadow-2xl overflow-visible">
              <div className="flex bg-black/50 border-b border-yellow-900/10 overflow-x-auto rounded-t-[2.5rem]">
                {[
                  { id: 'flights', icon: <Plane size={16} />, label: 'Flights' },
                  { id: 'hotels', icon: <Hotel size={16} />, label: 'Hotels' }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-3 px-10 py-7 text-[10px] font-black uppercase tracking-widest transition-all shrink-0 ${
                      activeTab === tab.id ? 'bg-yellow-500 text-black' : 'text-gray-400 hover:text-yellow-500'
                    }`}
                  >
                    {tab.icon} {tab.label}
                  </button>
                ))}
              </div>
              
              <div className="p-8 md:p-12">
                {activeTab === 'flights' ? (
                  <form onSubmit={handleBookingSearch} className="space-y-8">
                    <div className="flex gap-8 border-b border-yellow-900/10 pb-6">
                      {['One Way', 'Return', 'Multi-City'].map((type) => (
                        <label key={type} className="flex items-center gap-3 cursor-pointer group">
                          <input 
                            type="radio" 
                            name="tripType" 
                            className="hidden" 
                            checked={flightConfig.tripType === type} 
                            onChange={() => setFlightConfig({...flightConfig, tripType: type})} 
                          />
                          <div className={`w-4 h-4 rounded-full border border-yellow-500 flex items-center justify-center transition-all ${flightConfig.tripType === type ? 'bg-yellow-500' : 'bg-transparent'}`}>
                             {flightConfig.tripType === type && <div className="w-1.5 h-1.5 bg-black rounded-full"></div>}
                          </div>
                          <span className={`text-[10px] font-black uppercase tracking-widest transition-colors ${flightConfig.tripType === type ? 'text-yellow-500' : 'text-gray-500 group-hover:text-white'}`}>
                            {type}
                          </span>
                        </label>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                      <div className="space-y-3">
                        <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Departure (From)</label>
                        <div className="relative">
                          <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                          <input 
                            required list="cities"
                            type="text" placeholder="Origin City" 
                            className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 text-white font-medium"
                            value={flightConfig.origin}
                            onChange={(e) => setFlightConfig({...flightConfig, origin: e.target.value})}
                          />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Destination (To)</label>
                        <div className="relative">
                          <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                          <input 
                            required list="cities"
                            type="text" placeholder="To Where?" 
                            className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 text-white font-medium"
                            value={flightConfig.destination}
                            onChange={(e) => setFlightConfig({...flightConfig, destination: e.target.value})}
                          />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Departure Date</label>
                        <div className="relative">
                          <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                          <input 
                            required type="date" 
                            className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 text-gray-400"
                            value={flightConfig.departureDate}
                            onChange={(e) => setFlightConfig({...flightConfig, departureDate: e.target.value})}
                          />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className={`text-[9px] uppercase font-black tracking-widest ml-1 transition-opacity ${flightConfig.tripType === 'Return' ? 'text-yellow-500' : 'text-gray-700'}`}>Return Date</label>
                        <div className="relative">
                          <Calendar size={18} className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${flightConfig.tripType === 'Return' ? 'text-yellow-500' : 'text-gray-800'}`} />
                          <input 
                            disabled={flightConfig.tripType !== 'Return'}
                            required={flightConfig.tripType === 'Return'}
                            type="date" 
                            className={`w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 transition-all ${flightConfig.tripType === 'Return' ? 'text-gray-400' : 'text-gray-800 cursor-not-allowed'}`}
                            value={flightConfig.returnDate}
                            onChange={(e) => setFlightConfig({...flightConfig, returnDate: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                      <div className="space-y-3 relative">
                        <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Travellers</label>
                        <div 
                          onClick={() => setShowTravellerDropdown(!showTravellerDropdown)}
                          className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-sm text-white font-bold cursor-pointer flex justify-between items-center"
                        >
                          <div className="flex items-center gap-3">
                            <Users size={16} className="text-yellow-500" />
                            <span>{totalTravellers} Traveller{totalTravellers > 1 ? 's' : ''}</span>
                          </div>
                          <ChevronRight size={16} className={`text-yellow-500 transition-transform ${showTravellerDropdown ? 'rotate-90' : ''}`} />
                        </div>
                        
                        {showTravellerDropdown && (
                          <div className="absolute top-full left-0 w-72 bg-zinc-950 border border-yellow-900/30 rounded-2xl p-6 mt-2 z-50 shadow-2xl">
                             {[
                               { label: 'Adults', sub: '12+ Years', type: 'adults' },
                               { label: 'Children', sub: '2-12 Years', type: 'children' },
                               { label: 'Infants', sub: 'Below 2 Years', type: 'infants' }
                             ].map((cat) => (
                               <div key={cat.type} className="flex items-center justify-between mb-4 last:mb-0">
                                 <div>
                                   <p className="text-white text-xs font-black uppercase tracking-widest">{cat.label}</p>
                                   <p className="text-gray-500 text-[9px] font-bold uppercase">{cat.sub}</p>
                                 </div>
                                 <div className="flex items-center gap-4">
                                   <button onClick={() => updateTravellers(cat.type as any, 'sub')} type="button" className="w-8 h-8 rounded-full border border-yellow-900/30 flex items-center justify-center text-yellow-500 hover:bg-yellow-500 hover:text-black transition-all">
                                      <Minus size={14} />
                                   </button>
                                   <span className="text-white font-black text-xs w-4 text-center">{flightConfig.travellers[cat.type as keyof typeof flightConfig.travellers]}</span>
                                   <button onClick={() => updateTravellers(cat.type as any, 'add')} type="button" className="w-8 h-8 rounded-full border border-yellow-900/30 flex items-center justify-center text-yellow-500 hover:bg-yellow-500 hover:text-black transition-all">
                                      <Plus size={14} />
                                   </button>
                                 </div>
                               </div>
                             ))}
                          </div>
                        )}
                      </div>
                      <div className="space-y-3">
                        <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Cabin Class</label>
                        <select 
                          className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 px-6 text-sm focus:outline-none focus:border-yellow-500 text-white font-bold appearance-none"
                          value={flightConfig.cabin}
                          onChange={(e) => setFlightConfig({...flightConfig, cabin: e.target.value})}
                        >
                          {bookingCategories.flights.map(cat => <option key={cat}>{cat}</option>)}
                        </select>
                      </div>
                      <button type="submit" className="w-full btn-gold py-4 rounded-xl font-black uppercase tracking-widest text-[11px] shadow-xl active:scale-95 flex items-center justify-center gap-2 h-[54px]">
                        Search Best Fares <ChevronRight size={16} />
                      </button>
                    </div>
                  </form>
                ) : (
                  <form onSubmit={handleBookingSearch} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end">
                    <div className="space-y-3">
                      <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Location</label>
                      <div className="relative">
                        <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                        <input 
                          required list="cities"
                          type="text" placeholder="Where?" 
                          className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 text-white font-medium"
                          value={searchData.destination}
                          onChange={(e) => setSearchData({...searchData, destination: e.target.value})}
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Category</label>
                      <div className="relative">
                        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                        <select 
                          className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 text-white font-bold appearance-none"
                          value={searchData.category}
                          onChange={(e) => setSearchData({...searchData, category: e.target.value})}
                        >
                          {bookingCategories[activeTab].map(cat => <option key={cat}>{cat}</option>)}
                        </select>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[9px] uppercase text-yellow-500 font-black tracking-widest ml-1">Preferred Date</label>
                      <div className="relative">
                        <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                        <input 
                          required type="date" 
                          className="w-full bg-black border border-yellow-900/20 rounded-xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-yellow-500 text-gray-400"
                          value={searchData.date}
                          onChange={(e) => setSearchData({...searchData, date: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <button type="submit" className="w-full btn-gold py-4 rounded-xl font-black uppercase tracking-widest text-[11px] shadow-xl active:scale-95 flex items-center justify-center gap-2 h-[54px]">
                        Find Availablity <ChevronRight size={16} />
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <datalist id="cities">
          {globalCities.map(c => <option key={c} value={c} />)}
        </datalist>
      </section>

      <section className="bg-zinc-950 border-b border-yellow-900/10">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 divide-x divide-yellow-900/10">
          {[
            { label: "Best Price Guarantee", icon: <Shield size={20} /> },
            { label: "24/7 Expert Support", icon: <Headphones size={20} /> },
            { label: "Elite Members Program", icon: <Users size={20} /> },
            { label: "Global Presence", icon: <Globe size={20} /> }
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-center gap-4 py-8 px-4 text-center">
              <div className="text-yellow-500">{item.icon}</div>
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-black">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="flex justify-between items-end mb-16">
            <div>
              <span className="text-yellow-500 text-[10px] font-black uppercase tracking-[0.4em] mb-4 block">Trending Globally</span>
              <h2 className="text-4xl md:text-5xl font-serif font-bold">Unmissable <span className="gold-text-gradient italic">Holidays</span></h2>
            </div>
            <div className="flex gap-4">
              <button className="p-3 border border-yellow-900/20 rounded-full hover:bg-yellow-500 hover:text-black transition-all"><ChevronLeft size={20} /></button>
              <button className="p-3 border border-yellow-900/20 rounded-full hover:bg-yellow-500 hover:text-black transition-all"><ChevronRight size={20} /></button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {trendingDestinations.map((dest, i) => (
              <div key={i} className="group cursor-pointer">
                <div className="relative h-96 rounded-[2.5rem] overflow-hidden border border-yellow-900/10 group-hover:border-yellow-500/30 transition-all">
                  <img src={dest.img} alt={dest.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                  <div className="absolute bottom-10 left-10">
                    <h3 className="text-3xl font-serif font-bold text-white mb-2">{dest.name}</h3>
                    <p className="text-yellow-500 text-[10px] font-black uppercase tracking-widest">Starting AED {dest.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-black overflow-hidden">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="bg-gradient-to-br from-zinc-900 to-black rounded-[4rem] border border-yellow-900/20 p-12 md:p-24 relative">
             <div className="absolute top-0 right-0 w-96 h-96 gold-gradient opacity-5 blur-[100px] -mr-48 -mt-48"></div>
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                <div className="space-y-8">
                  <div className="flex items-center gap-3 text-yellow-500">
                    <Briefcase size={20} />
                    <span className="text-[10px] font-black uppercase tracking-[0.4em]">Corporate Solutions</span>
                  </div>
                  <h2 className="text-4xl md:text-5xl font-serif font-bold text-white">Elite Management <br />for Global Business</h2>
                  <p className="text-gray-400 font-light text-lg">
                    Streamline your organization's travel with our dedicated MICE desk. From diplomatic missions to corporate delegations, we ensure precision logistics.
                  </p>
                  <ul className="space-y-4">
                    {["24/7 Dedicated Account Manager", "Preferred Corporate Hotel Rates", "Transparent Monthly Billing", "Global Flight Access"].map((f, i) => (
                      <li key={i} className="flex items-center gap-4 text-xs font-bold uppercase tracking-wider text-gray-300">
                        <div className="h-1.5 w-1.5 rounded-full gold-gradient"></div> {f}
                      </li>
                    ))}
                  </ul>
                  <button onClick={() => navigate('/contact')} className="border-2 border-yellow-500/30 text-yellow-500 px-10 py-4 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-yellow-500 transition-all hover:text-black">
                    Inquire Corporate Desk
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="aspect-square bg-zinc-950 rounded-3xl border border-yellow-900/10 flex flex-col items-center justify-center text-center p-8 group hover:border-yellow-500/30 transition-all">
                    <Clock3 size={32} className="text-yellow-500 mb-4 group-hover:scale-110 transition-transform" />
                    <h4 className="text-white font-bold text-xs uppercase mb-2">Punctuality</h4>
                    <p className="text-[9px] text-gray-500 uppercase font-black">Guaranteed On-Time</p>
                  </div>
                  <div className="aspect-square bg-zinc-950 rounded-3xl border border-yellow-900/10 flex flex-col items-center justify-center text-center p-8 group hover:border-yellow-500/30 transition-all">
                    <Shield size={32} className="text-yellow-500 mb-4 group-hover:scale-110 transition-transform" />
                    <h4 className="text-white font-bold text-xs uppercase mb-2">Discretion</h4>
                    <p className="text-[9px] text-gray-500 uppercase font-black">Confidential Handling</p>
                  </div>
                </div>
             </div>
          </div>
        </div>
      </section>

      <section className="py-24 border-t border-yellow-900/10">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-serif font-bold text-white mb-10">Trusted by Global Travelers</h2>
          <div className="flex flex-wrap justify-center gap-12 opacity-30 grayscale hover:grayscale-0 transition-all">
            <span className="text-2xl font-black text-white italic">DUBAI SOUTH</span>
            <span className="text-2xl font-black text-white italic">ABU DHABI</span>
            <span className="text-2xl font-black text-white italic">IATA CERTIFIED</span>
            <span className="text-2xl font-black text-white italic">ELITE TRAVELS</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
