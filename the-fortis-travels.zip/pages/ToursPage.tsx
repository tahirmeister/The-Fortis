
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Star, MapPin, ArrowRight, Clock, ShieldCheck, Camera, Compass, Coffee, Loader2 } from 'lucide-react';

const tours = [
  {
    title: "Burj Khalifa: Level 124 & 125",
    img: "https://images.unsplash.com/photo-1582730147043-60bd6361bc2b?auto=format&fit=crop&q=80&w=800",
    price: "179",
    rating: "4.9",
    location: "Downtown Dubai",
    category: "Sightseeing",
    duration: "2 Hours"
  },
  {
    title: "Premium Evening Desert Safari",
    img: "https://images.unsplash.com/photo-1506461883276-594a12b11cf3?auto=format&fit=crop&q=80&w=800",
    price: "145",
    rating: "4.8",
    location: "Lahbab Desert",
    category: "Adventure",
    duration: "6 Hours"
  },
  {
    title: "Dubai Marina Luxury Yacht Tour",
    img: "https://images.unsplash.com/photo-1540962351504-03099e0a754b?auto=format&fit=crop&q=80&w=800",
    price: "250",
    rating: "4.9",
    location: "Dubai Marina",
    category: "Luxury",
    duration: "3 Hours"
  },
  {
    title: "Abu Dhabi Full Day City Tour",
    img: "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&q=80&w=800",
    price: "220",
    rating: "4.7",
    location: "Abu Dhabi",
    category: "City Tour",
    duration: "10 Hours"
  },
  {
    title: "The Museum of the Future",
    img: "https://images.unsplash.com/photo-1644310972589-643a2099d946?auto=format&fit=crop&q=80&w=800",
    price: "145",
    rating: "5.0",
    location: "Sheikh Zayed Rd",
    category: "Museums",
    duration: "3 Hours"
  },
  {
    title: "Atlantis Aquaventure Waterpark",
    img: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=800",
    price: "299",
    rating: "4.8",
    location: "Palm Jumeirah",
    category: "Theme Parks",
    duration: "Full Day"
  }
];

const ToursPage: React.FC = () => {
  const [isBooking, setIsBooking] = useState(false);
  const navigate = useNavigate();

  const handleInstantBook = (tourTitle: string) => {
    setIsBooking(true);
    setTimeout(() => {
      setIsBooking(false);
      navigate('/payment');
    }, 2000);
  };

  return (
    <div className="bg-black min-h-screen pt-12 relative">
      {isBooking && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center">
          <Loader2 className="w-16 h-16 text-yellow-500 animate-spin mb-6" />
          <h2 className="text-xl font-serif font-bold gold-text-gradient">Reserving Your Spot...</h2>
          <p className="text-gray-500 text-[10px] uppercase tracking-widest mt-2">Connecting to Real-Time Operator</p>
        </div>
      )}

      <section className="relative py-24 border-b border-yellow-900/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <span className="text-yellow-500 font-bold uppercase tracking-[0.4em] text-xs mb-4 block">Experiences</span>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">World-Class <br /><span className="gold-text-gradient italic">Dubai Tours</span></h1>
            <p className="text-gray-400 text-lg font-light leading-relaxed">
              Explore our curated selection of the most sought-after attractions and tours in Dubai and the UAE. Every experience is vetted for quality and luxury.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-zinc-950/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-4 overflow-x-auto pb-10 scrollbar-hide">
            {['All Tours', 'Adventure', 'Sightseeing', 'Luxury', 'Theme Parks', 'City Tours'].map((cat, i) => (
              <button key={i} className={`px-8 py-3 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all whitespace-nowrap ${i === 0 ? 'bg-yellow-500 text-black border-yellow-500' : 'border-yellow-900/30 text-gray-500 hover:border-yellow-500'}`}>
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tours.map((tour, i) => (
              <div key={i} className="group bg-black rounded-[2.5rem] border border-yellow-900/10 overflow-hidden hover:border-yellow-500/40 transition-all flex flex-col h-full shadow-2xl">
                <div className="relative h-64 overflow-hidden">
                  <img src={tour.img} alt={tour.title} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                  <div className="absolute top-5 left-5 bg-yellow-500 text-black text-[9px] font-black uppercase px-4 py-1.5 rounded-full">{tour.category}</div>
                  <div className="absolute bottom-5 right-5 bg-black/70 backdrop-blur-md p-2 rounded-xl text-yellow-500 flex items-center gap-1 border border-yellow-500/20">
                    <Star size={12} fill="currentColor" />
                    <span className="text-xs font-black">{tour.rating}</span>
                  </div>
                </div>
                <div className="p-8 flex-grow flex flex-col">
                  <div className="flex items-center gap-4 text-gray-500 text-[9px] uppercase font-black tracking-widest mb-4">
                    <div className="flex items-center gap-1"><MapPin size={12} className="text-yellow-500" /> {tour.location}</div>
                    <div className="flex items-center gap-1"><Clock size={12} className="text-yellow-500" /> {tour.duration}</div>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-6 leading-tight group-hover:text-yellow-500 transition-colors">{tour.title}</h3>
                  <div className="mt-auto flex items-center justify-between pt-8 border-t border-yellow-900/10">
                    <div>
                      <p className="text-[9px] text-gray-500 uppercase font-black tracking-widest mb-1">Starts From</p>
                      <p className="text-2xl font-bold gold-text-gradient">AED {tour.price}</p>
                    </div>
                    <button 
                      onClick={() => handleInstantBook(tour.title)}
                      className="w-12 h-12 bg-yellow-500 text-black rounded-2xl flex items-center justify-center hover:bg-white transition-all shadow-xl shadow-yellow-500/20 active:scale-95"
                    >
                      <ArrowRight size={20} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-serif font-bold mb-16 uppercase">The Fortis <span className="gold-text-gradient">Advantage</span></h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: <ShieldCheck size={32} />, title: "Secure Booking", desc: "Encrypted payment portal." },
              { icon: <Camera size={32} />, title: "Best Views", desc: "Top-tier photography spots." },
              { icon: <Compass size={32} />, title: "Expert Guides", desc: "Local knowledge & history." },
              { icon: <Coffee size={32} />, title: "VIP Access", desc: "No queues, luxury entry." }
            ].map((item, i) => (
              <div key={i} className="space-y-4 p-8 border border-yellow-900/10 rounded-3xl">
                <div className="text-yellow-500 mx-auto w-fit">{item.icon}</div>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">{item.title}</h4>
                <p className="text-gray-500 text-[10px] font-light">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ToursPage;
