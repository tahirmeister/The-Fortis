
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Plane, 
  Search, 
  MapPin, 
  Calendar, 
  Users, 
  Filter, 
  ArrowRight, 
  Clock, 
  ShieldCheck, 
  Sparkles,
  ChevronRight,
  ChevronDown,
  Wind,
  Wifi,
  Coffee,
  Loader2,
  Plus,
  Minus,
  Trash2,
  AlertCircle
} from 'lucide-react';

interface Flight {
  id: string;
  airline: string;
  logo: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  duration: string;
  stops: number;
  price: string;
  class: string;
}

const AIRLINES = [
  { name: "Emirates", logo: "EK" },
  { name: "Etihad Airways", logo: "EY" },
  { name: "Qatar Airways", logo: "QR" },
  { name: "British Airways", logo: "BA" },
  { name: "Singapore Airlines", logo: "SQ" },
  { name: "Lufthansa", logo: "LH" }
];

const FlightsPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSearching, setIsSearching] = useState(false);
  const [activeFlights, setActiveFlights] = useState<Flight[]>([]);
  const [showTravellerDropdown, setShowTravellerDropdown] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  // Advanced Flight State
  const [tripType, setTripType] = useState('Return');
  const [cabinClass, setCabinClass] = useState('Economy');
  const [travellers, setTravellers] = useState({ adults: 1, children: 0, infants: 0 });
  
  // Dynamic legs for Multi-City
  const [legs, setLegs] = useState([
    { origin: 'Dubai (DXB)', destination: '', date: '' },
    { origin: '', destination: '', date: '' }
  ]);

  // Standard Return/OneWay state
  const [mainOrigin, setMainOrigin] = useState('Dubai (DXB)');
  const [mainDest, setMainDest] = useState('');
  const [departureDate, setDepartureDate] = useState('');
  const [returnDate, setReturnDate] = useState('');

  // Effect to handle incoming search state from Home Page
  useEffect(() => {
    if (location.state?.flightDetails) {
      const details = location.state.flightDetails;
      setTripType(details.tripType);
      setMainOrigin(details.origin);
      setMainDest(details.destination);
      setDepartureDate(details.departureDate);
      setReturnDate(details.returnDate);
      setTravellers(details.travellers);
      setCabinClass(details.cabin.replace(' Class', ''));
      
      // Trigger search automatically if we have required fields
      if (details.origin && details.destination) {
        performSearch(details.origin, details.destination, details.tripType);
      }
    } else if (location.state?.location) {
      // Fallback for simple search
      setMainDest(location.state.location);
      performSearch(mainOrigin, location.state.location, tripType);
    }
  }, [location.state]);

  const performSearch = (from: string, to: string, type: string) => {
    setIsSearching(true);
    setHasSearched(true);
    
    // Simulate a complex search calculation
    setTimeout(() => {
      const results: Flight[] = [];
      const fromCode = from.match(/\(([^)]+)\)/)?.[1] || from.substring(0, 3).toUpperCase();
      const toCode = to.match(/\(([^)]+)\)/)?.[1] || to.substring(0, 3).toUpperCase();

      // Generate 3-5 realistic results for the exact route
      const numResults = 3 + Math.floor(Math.random() * 3);
      
      for (let i = 0; i < numResults; i++) {
        const airline = AIRLINES[Math.floor(Math.random() * AIRLINES.length)];
        const depHour = Math.floor(Math.random() * 24);
        const depMin = [0, 15, 30, 45][Math.floor(Math.random() * 4)];
        const durationHours = 4 + Math.floor(Math.random() * 10);
        const arrHour = (depHour + durationHours) % 24;
        
        results.push({
          id: `${airline.logo}${100 + Math.floor(Math.random() * 900)}`,
          airline: airline.name,
          logo: "", // Managed by CSS/Icon
          from: fromCode,
          to: toCode,
          departure: `${depHour.toString().padStart(2, '0')}:${depMin.toString().padStart(2, '0')}`,
          arrival: `${arrHour.toString().padStart(2, '0')}:${depMin.toString().padStart(2, '0')}`,
          duration: `${durationHours}h ${Math.floor(Math.random() * 60)}m`,
          stops: Math.random() > 0.7 ? 1 : 0,
          price: (1200 + Math.floor(Math.random() * 5000)).toLocaleString(),
          class: cabinClass
        });
      }

      setActiveFlights(results);
      setIsSearching(false);
    }, 1500);
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    performSearch(mainOrigin, mainDest, tripType);
  };

  const handleBookFlight = (flight: Flight) => {
    navigate('/payment', {
      state: {
        itemTitle: `${flight.airline} ${flight.id}`,
        location: `${flight.from} to ${flight.to}`,
        date: departureDate || "Instant Booking",
        type: "FLIGHT BOOKING",
        price: flight.price.replace(',', '')
      }
    });
  };

  const updateTravellers = (type: 'adults' | 'children' | 'infants', op: 'add' | 'sub') => {
    setTravellers(prev => ({
      ...prev,
      [type]: op === 'add' ? prev[type] + 1 : Math.max(type === 'adults' ? 1 : 0, prev[type] - 1)
    }));
  };

  const addLeg = () => {
    if (legs.length < 5) {
      setLegs([...legs, { origin: legs[legs.length - 1].destination, destination: '', date: '' }]);
    }
  };

  const removeLeg = (index: number) => {
    if (legs.length > 2) {
      setLegs(legs.filter((_, i) => i !== index));
    }
  };

  const totalTravellers = travellers.adults + travellers.children + travellers.infants;

  return (
    <div className="bg-black min-h-screen pt-32 pb-24">
      {isSearching && (
        <div className="fixed inset-0 z-[200] bg-black/95 flex flex-col items-center justify-center">
          <Loader2 className="w-16 h-16 text-yellow-500 animate-spin mb-6" />
          <h2 className="text-2xl font-serif font-bold gold-text-gradient">Scanning Global Airlines</h2>
          <p className="text-gray-500 text-[10px] uppercase tracking-widest mt-4">Direct GDS Query: {mainOrigin} to {mainDest}</p>
        </div>
      )}

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-16">
          <span className="text-yellow-500 font-bold uppercase tracking-[0.5em] text-[10px] mb-4 block">Air Travel Portal</span>
          <h1 className="text-4xl md:text-7xl font-serif font-bold text-white mb-6">Wings of <span className="gold-text-gradient italic">Excellence</span></h1>
          <p className="text-gray-400 max-w-2xl font-light text-lg">
            Access real-time schedules and exclusive rates from over 400 global carriers. Our IATA-certified desk ensures seamless connections for discerning travellers.
          </p>
        </div>

        {/* Search Interface */}
        <div className="bg-zinc-950 border border-yellow-900/20 rounded-[3rem] p-8 md:p-12 shadow-2xl mb-24 relative overflow-visible">
          <div className="absolute top-0 left-0 w-full h-1 gold-gradient"></div>
          
          <div className="flex flex-wrap gap-12 mb-10 border-b border-yellow-900/10 pb-8">
            <div className="flex bg-black p-1 rounded-full border border-yellow-900/20 h-[46px] items-center">
              {['One Way', 'Return', 'Multi-City'].map((type) => (
                <button 
                  key={type}
                  onClick={() => setTripType(type)}
                  className={`px-8 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all h-full flex items-center ${tripType === type ? 'bg-yellow-500 text-black shadow-lg' : 'text-gray-500 hover:text-white'}`}
                >
                  {type}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-8">
              <div className="relative">
                <div 
                  onClick={() => setShowTravellerDropdown(!showTravellerDropdown)}
                  className="bg-black border border-yellow-900/20 rounded-full px-8 py-3 text-[10px] font-black uppercase tracking-widest text-white cursor-pointer hover:border-yellow-500 transition-all flex items-center gap-3 min-w-[180px]"
                >
                  <Users size={14} className="text-yellow-500" />
                  {totalTravellers} Passenger{totalTravellers > 1 ? 's' : ''}
                </div>
                {showTravellerDropdown && (
                  <div className="absolute top-full left-0 w-72 bg-zinc-950 border border-yellow-900/30 rounded-2xl p-6 mt-2 z-50 shadow-2xl">
                     {[
                       { label: 'Adults', sub: '12+ Years', type: 'adults' },
                       { label: 'Children', sub: '2-12 Years', type: 'children' },
                       { label: 'Infants', sub: 'Below 2 Years', type: 'infants' }
                     ].map((cat) => (
                       <div key={cat.type} className="flex items-center justify-between mb-4 last:mb-0">
                         <div>
                           <p className="text-white text-xs font-black uppercase tracking-widest">{cat.label}</p>
                           <p className="text-gray-500 text-[9px] font-bold uppercase">{cat.sub}</p>
                         </div>
                         <div className="flex items-center gap-4">
                           <button onClick={() => updateTravellers(cat.type as any, 'sub')} type="button" className="w-8 h-8 rounded-full border border-yellow-900/30 flex items-center justify-center text-yellow-500 hover:bg-yellow-500 hover:text-black transition-all">
                              <Minus size={14} />
                           </button>
                           <span className="text-white font-black text-xs w-4 text-center">{travellers[cat.type as keyof typeof travellers]}</span>
                           <button onClick={() => updateTravellers(cat.type as any, 'add')} type="button" className="w-8 h-8 rounded-full border border-yellow-900/30 flex items-center justify-center text-yellow-500 hover:bg-yellow-500 hover:text-black transition-all">
                              <Plus size={14} />
                           </button>
                         </div>
                       </div>
                     ))}
                  </div>
                )}
              </div>

              <select 
                value={cabinClass}
                onChange={(e) => setCabinClass(e.target.value)}
                className="bg-black border border-yellow-900/20 rounded-full px-8 py-3 text-[10px] font-black uppercase tracking-widest text-yellow-500 focus:outline-none focus:border-yellow-500 appearance-none cursor-pointer"
              >
                <option>Economy</option>
                <option>Premium Economy</option>
                <option>Business Class</option>
                <option>First Class</option>
              </select>
            </div>
          </div>

          <form onSubmit={handleSearch}>
            {tripType === 'Multi-City' ? (
              <div className="space-y-6">
                {legs.map((leg, idx) => (
                  <div key={idx} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end group">
                    <div className="space-y-3">
                      <label className="text-[9px] uppercase text-gray-500 font-black tracking-widest ml-1">Leg {idx + 1}: Departure</label>
                      <div className="relative">
                        <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                        <input 
                          type="text" 
                          value={leg.origin}
                          onChange={(e) => {
                            const newLegs = [...legs];
                            newLegs[idx].origin = e.target.value;
                            setLegs(newLegs);
                          }}
                          className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-yellow-500 font-bold"
                          placeholder="Origin"
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[9px] uppercase text-gray-500 font-black tracking-widest ml-1">Leg {idx + 1}: Arrival</label>
                      <div className="relative">
                        <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                        <input 
                          type="text" 
                          value={leg.destination}
                          onChange={(e) => {
                            const newLegs = [...legs];
                            newLegs[idx].destination = e.target.value;
                            setLegs(newLegs);
                          }}
                          className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-yellow-500 font-bold"
                          placeholder="To Where?"
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[9px] uppercase text-gray-500 font-black tracking-widest ml-1">Date</label>
                      <div className="relative">
                        <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                        <input 
                          type="date" 
                          className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm text-gray-400 focus:outline-none focus:border-yellow-500"
                        />
                      </div>
                    </div>
                    <div className="flex gap-4 h-[54px]">
                      {legs.length > 2 && (
                        <button 
                          type="button" 
                          onClick={() => removeLeg(idx)}
                          className="w-14 h-full bg-red-900/10 border border-red-900/20 text-red-500 rounded-2xl flex items-center justify-center hover:bg-red-500 hover:text-white transition-all"
                        >
                          <Trash2 size={18} />
                        </button>
                      )}
                      {idx === legs.length - 1 && legs.length < 5 && (
                        <button 
                          type="button" 
                          onClick={addLeg}
                          className="flex-grow bg-zinc-900 border border-yellow-900/20 text-yellow-500 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-yellow-500 hover:text-black transition-all"
                        >
                          <Plus size={16} /> Add Leg
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                <div className="pt-6 border-t border-yellow-900/10 flex justify-end">
                   <button type="submit" className="btn-gold px-16 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl flex items-center justify-center gap-2">
                    Search Multi-City <Search size={16} />
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 items-end">
                <div className="space-y-3">
                  <label className="text-[9px] uppercase text-gray-500 font-black tracking-widest ml-1">Departure (From)</label>
                  <div className="relative">
                    <Wind size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                    <input 
                      type="text" 
                      value={mainOrigin}
                      onChange={(e) => setMainOrigin(e.target.value)}
                      className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-yellow-500 font-bold"
                      placeholder="Origin"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase text-gray-500 font-black tracking-widest ml-1">Destination (To)</label>
                  <div className="relative">
                    <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                    <input 
                      required
                      type="text" 
                      value={mainDest}
                      onChange={(e) => setMainDest(e.target.value)}
                      className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-yellow-500 font-bold"
                      placeholder="To Where?"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase text-gray-500 font-black tracking-widest ml-1">Departure Date</label>
                  <div className="relative">
                    <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" />
                    <input 
                      required
                      value={departureDate}
                      onChange={(e) => setDepartureDate(e.target.value)}
                      type="date" 
                      className="w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm text-gray-400 focus:outline-none focus:border-yellow-500"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className={`text-[9px] uppercase font-black tracking-widest ml-1 transition-opacity ${tripType === 'Return' ? 'text-gray-500' : 'text-gray-900'}`}>Return Date</label>
                  <div className="relative">
                    <Calendar size={18} className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${tripType === 'Return' ? 'text-yellow-500' : 'text-gray-900'}`} />
                    <input 
                      disabled={tripType !== 'Return'}
                      required={tripType === 'Return'}
                      value={returnDate}
                      onChange={(e) => setReturnDate(e.target.value)}
                      type="date" 
                      className={`w-full bg-black border border-yellow-900/30 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none transition-all ${tripType === 'Return' ? 'text-gray-400 border-yellow-900/30' : 'text-gray-900 border-transparent cursor-not-allowed'}`}
                    />
                  </div>
                </div>
                <div>
                  <button type="submit" className="w-full btn-gold py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl flex items-center justify-center gap-2">
                    Search Flights <Search size={16} />
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>

        {/* Results Section */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          
          <div className="hidden lg:block space-y-8">
            <div className="bg-zinc-950 p-10 rounded-[2.5rem] border border-yellow-900/10 shadow-xl">
              <h3 className="text-white font-bold text-xs uppercase tracking-widest mb-8 flex items-center justify-between">
                Refine Search <Filter size={14} className="text-yellow-500" />
              </h3>
              
              <div className="space-y-10">
                <div className="space-y-4">
                  <p className="text-[9px] uppercase font-black text-gray-500 tracking-widest">Airlines</p>
                  {AIRLINES.map(airline => (
                    <label key={airline.name} className="flex items-center gap-3 cursor-pointer group">
                      <div className="w-4 h-4 rounded border border-yellow-900/30 flex items-center justify-center group-hover:border-yellow-500 transition-all">
                        <div className="w-2 h-2 rounded-full bg-yellow-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      </div>
                      <span className="text-[10px] font-bold uppercase text-gray-400 group-hover:text-white transition-colors">{airline.name}</span>
                    </label>
                  ))}
                </div>

                <div className="space-y-4">
                  <p className="text-[9px] uppercase font-black text-gray-500 tracking-widest">Stops</p>
                  {['Non-stop', '1 Stop', '2+ Stops'].map(stop => (
                    <label key={stop} className="flex items-center gap-3 cursor-pointer group">
                      <div className="w-4 h-4 rounded border border-yellow-900/30 flex items-center justify-center group-hover:border-yellow-500 transition-all">
                        <div className="w-2 h-2 rounded-full bg-yellow-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      </div>
                      <span className="text-[10px] font-bold uppercase text-gray-400 group-hover:text-white transition-colors">{stop}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-10 bg-yellow-500/5 border border-yellow-500/10 rounded-[2.5rem] text-center">
              <ShieldCheck className="text-yellow-500 mx-auto mb-6" size={40} />
              <p className="text-white font-bold uppercase tracking-widest text-[10px] mb-2">Secure Ticketing</p>
              <p className="text-gray-500 text-[9px] font-black uppercase">Official IATA Partner</p>
            </div>
          </div>

          <div className="lg:col-span-3 space-y-6">
            {!hasSearched ? (
              <div className="py-24 text-center bg-zinc-950/30 border border-yellow-900/10 rounded-[3rem]">
                <Plane size={48} className="text-yellow-500/20 mx-auto mb-6" />
                <h3 className="text-white font-serif text-2xl mb-2">Ready to Take Flight?</h3>
                <p className="text-gray-500 text-sm">Enter your destination above to scan available premium fares.</p>
              </div>
            ) : activeFlights.length > 0 ? (
              <>
                <div className="flex justify-between items-center mb-8 px-4">
                  <p className="text-[10px] font-black uppercase text-gray-500 tracking-widest">
                    Showing {activeFlights.length} Direct Matches for "{mainOrigin} to {mainDest}"
                  </p>
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase text-yellow-500 tracking-widest cursor-pointer hover:underline">
                    Sort: Recommended <ChevronDown size={14} />
                  </div>
                </div>

                {activeFlights.map((flight) => (
                  <div key={flight.id} className="bg-zinc-950 border border-yellow-900/10 rounded-[2rem] p-8 md:p-12 hover:border-yellow-500/40 transition-all group shadow-xl">
                    <div className="flex flex-col md:flex-row items-center gap-12">
                      <div className="w-full md:w-48 text-center md:text-left">
                        <div className="h-12 w-32 mx-auto md:mx-0 bg-white/5 rounded-xl flex items-center justify-center p-2 mb-4 group-hover:bg-white/10 transition-all">
                          <span className="text-white font-black text-xs italic">{flight.airline}</span>
                        </div>
                        <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest">{flight.id}</p>
                      </div>

                      <div className="flex-grow grid grid-cols-3 gap-8 items-center text-center">
                        <div>
                          <h4 className="text-2xl font-bold text-white mb-1 tracking-tight">{flight.departure}</h4>
                          <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">{flight.from}</p>
                        </div>
                        <div className="relative">
                          <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest mb-4">{flight.duration}</p>
                          <div className="h-px w-full bg-yellow-900/30 relative">
                            <div className="absolute inset-0 bg-yellow-500 scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-700"></div>
                            <Plane size={14} className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-yellow-500 group-hover:translate-x-full transition-transform duration-700" />
                          </div>
                          <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest mt-4">
                            {flight.stops === 0 ? 'Direct' : `${flight.stops} Stop`}
                          </p>
                        </div>
                        <div>
                          <h4 className="text-2xl font-bold text-white mb-1 tracking-tight">{flight.arrival}</h4>
                          <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">{flight.to}</p>
                        </div>
                      </div>

                      <div className="w-full md:w-56 text-center md:text-right border-t md:border-t-0 md:border-l border-yellow-900/10 pt-8 md:pt-0 md:pl-12">
                        <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest mb-1">Total Trip Price</p>
                        <h3 className="text-3xl font-bold gold-text-gradient mb-6 tracking-tighter">AED {flight.price}</h3>
                        <button 
                          onClick={() => handleBookFlight(flight)}
                          className="w-full btn-gold py-4 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-3 active:scale-95"
                        >
                          Instant Book <ChevronRight size={14} />
                        </button>
                      </div>
                    </div>

                    <div className="mt-8 pt-8 border-t border-yellow-900/5 flex flex-wrap gap-8">
                      <div className="flex items-center gap-2 text-gray-500 text-[9px] font-black uppercase tracking-widest">
                        <Wifi size={14} className="text-yellow-500" /> High-Speed Connectivity
                      </div>
                      <div className="flex items-center gap-2 text-gray-500 text-[9px] font-black uppercase tracking-widest">
                        <Coffee size={14} className="text-yellow-500" /> Premium Dining
                      </div>
                      <div className="flex items-center gap-2 text-gray-500 text-[9px] font-black uppercase tracking-widest ml-auto">
                        <Sparkles size={14} className="text-yellow-500" /> Elite Flex Booking
                      </div>
                    </div>
                  </div>
                ))}
              </>
            ) : (
              <div className="py-24 text-center bg-zinc-950/30 border border-yellow-900/10 rounded-[3rem]">
                <AlertCircle size={48} className="text-yellow-500/20 mx-auto mb-6" />
                <h3 className="text-white font-serif text-2xl mb-2">No Flights Found</h3>
                <p className="text-gray-500 text-sm max-w-md mx-auto">We couldn't find exact matches for this route in our real-time portal. Speak to our global desk for a custom charter or specialized connection.</p>
                <button onClick={() => setHasSearched(false)} className="mt-8 text-yellow-500 underline uppercase tracking-widest text-[10px] font-black">Reset Search</button>
              </div>
            )}
          </div>
        </div>

        <section className="mt-40">
          <div className="bg-gradient-to-br from-zinc-900 to-black rounded-[4rem] border border-yellow-900/20 p-16 md:p-32 relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 w-96 h-96 gold-gradient opacity-5 blur-[120px] -mr-48 -mt-48"></div>
            <div className="max-w-3xl mx-auto relative z-10">
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-8">Exclusive <br /><span className="gold-text-gradient italic">Private Aviation?</span></h2>
              <p className="text-gray-400 text-lg md:text-xl font-light leading-relaxed mb-12">
                When schedule precision is non-negotiable. Our global network provides access to 2,500+ private jets for diplomatic, corporate, or leisure charter requirements.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-6">
                <button className="btn-gold px-12 py-5 rounded-full text-[10px] font-black uppercase tracking-widest">
                  View Private Fleet
                </button>
                <button onClick={() => navigate('/contact')} className="border border-yellow-500/30 text-yellow-500 px-12 py-5 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-yellow-500/5 transition-all">
                  Inquire Charter Desk
                </button>
              </div>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
};

export default FlightsPage;
