
import React, { useState, useMemo } from 'react';
import { MapPin, ArrowUpRight, Search, Globe, Compass, Sparkles } from 'lucide-react';

interface City {
  name: string;
  country: string;
}

interface Region {
  name: string;
  description: string;
  cities: City[];
  image: string;
}

const worldDestinations: Region[] = [
  {
    name: "Middle East",
    description: "The pinnacle of modern opulence, where futuristic skylines meet timeless desert traditions. Experience unmatched hospitality in the world's most innovative luxury hubs, from the heights of Dubai to the cultural depths of Muscat.",
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=1200",
    cities: [
      { name: "Dubai", country: "UAE" }, { name: "Abu Dhabi", country: "UAE" }, { name: "Doha", country: "Qatar" },
      { name: "Riyadh", country: "Saudi Arabia" }, { name: "Jeddah", country: "Saudi Arabia" }, { name: "Muscat", country: "Oman" },
      { name: "Kuwait City", country: "Kuwait" }, { name: "Manama", country: "Bahrain" }, { name: "Amman", country: "Jordan" },
      { name: "Beirut", country: "Lebanon" }, { name: "Cairo", country: "Egypt" }, { name: "Alexandria", country: "Egypt" }
    ]
  },
  {
    name: "Europe",
    description: "A tapestry of heritage, art, and refined elegance. From the high-fashion avenues of Milan and Paris to the historic grand hotels of London and Vienna, Europe remains the classic heart of global sophistication.",
    image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&q=80&w=1200",
    cities: [
      { name: "Paris", country: "France" }, { name: "London", country: "UK" }, { name: "Rome", country: "Italy" },
      { name: "Berlin", country: "Germany" }, { name: "Madrid", country: "Spain" }, { name: "Amsterdam", country: "Netherlands" },
      { name: "Vienna", country: "Austria" }, { name: "Prague", country: "Czech Republic" }, { name: "Barcelona", country: "Spain" },
      { name: "Milan", country: "Italy" }, { name: "Zurich", country: "Switzerland" }, { name: "Geneva", country: "Switzerland" },
      { name: "Lisbon", country: "Portugal" }, { name: "Athens", country: "Greece" }, { name: "Stockholm", country: "Sweden" },
      { name: "Oslo", country: "Norway" }, { name: "Copenhagen", country: "Denmark" }, { name: "Brussels", country: "Belgium" },
      { name: "Munich", country: "Germany" }, { name: "Venice", country: "Italy" }, { name: "Florence", country: "Italy" }
    ]
  },
  {
    name: "Asia & Pacific",
    description: "An exquisite blend of high-tech dynamism and serene spiritual retreats. Discover secluded Balinese sanctuaries, cutting-edge urban centers like Tokyo, and the world's finest boutique wellness experiences in the Pacific.",
    image: "https://images.unsplash.com/photo-1528181304800-2f140819ad9c?auto=format&fit=crop&q=80&w=1200",
    cities: [
      { name: "Tokyo", country: "Japan" }, { name: "Seoul", country: "South Korea" }, { name: "Singapore", country: "Singapore" },
      { name: "Hong Kong", country: "China" }, { name: "Bangkok", country: "Thailand" }, { name: "Shanghai", country: "China" },
      { name: "Beijing", country: "China" }, { name: "Mumbai", country: "India" }, { name: "New Delhi", country: "India" },
      { name: "Taipei", country: "Taiwan" }, { name: "Kuala Lumpur", country: "Malaysia" }, { name: "Ho Chi Minh City", country: "Vietnam" },
      { name: "Sydney", country: "Australia" }, { name: "Melbourne", country: "Australia" }, { name: "Auckland", country: "New Zealand" },
      { name: "Bali", country: "Indonesia" }, { name: "Phuket", country: "Thailand" }, { name: "Kyoto", country: "Japan" }
    ]
  },
  {
    name: "Americas",
    description: "Vibrant energy meets diverse landscapes. Whether it's the cosmopolitan buzz of Manhattan or the exclusive coastal retreats of Rio, the Americas offer a bold, modern take on high-end living and exploration.",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&q=80&w=1200",
    cities: [
      { name: "New York", country: "USA" }, { name: "Los Angeles", country: "USA" }, { name: "Chicago", country: "USA" },
      { name: "Miami", country: "USA" }, { name: "San Francisco", country: "USA" }, { name: "Toronto", country: "Canada" },
      { name: "Vancouver", country: "Canada" }, { name: "Montreal", country: "Canada" }, { name: "Mexico City", country: "Mexico" },
      { name: "Rio de Janeiro", country: "Brazil" }, { name: "Sao Paulo", country: "Brazil" }, { name: "Buenos Aires", country: "Argentina" },
      { name: "Santiago", country: "Chile" }, { name: "Bogota", country: "Colombia" }, { name: "Lima", country: "Peru" }
    ]
  },
  {
    name: "Africa",
    description: "The ultimate frontier of luxury and raw beauty. Embark on sophisticated safaris under endless skies in Kenya and relax in world-class lodges in Cape Town that redefine the concept of exclusive, sustainable adventure.",
    image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&q=80&w=1200",
    cities: [
      { name: "Cape Town", country: "South Africa" }, { name: "Marrakech", country: "Morocco" }, { name: "Nairobi", country: "Kenya" },
      { name: "Johannesburg", country: "South Africa" }, { name: "Casablanca", country: "Morocco" }, { name: "Lagos", country: "Nigeria" },
      { name: "Addis Ababa", country: "Ethiopia" }, { name: "Tunis", country: "Tunisia" }, { name: "Algiers", country: "Algeria" }
    ]
  }
];

const DestinationsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredDestinations = useMemo(() => {
    if (!searchTerm) return worldDestinations;
    
    return worldDestinations.map(region => {
      const matchingCities = region.cities.filter(city => 
        city.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        city.country.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      const regionMatches = region.name.toLowerCase().includes(searchTerm.toLowerCase());

      return {
        ...region,
        cities: regionMatches ? region.cities : matchingCities,
        hasMatch: regionMatches || matchingCities.length > 0
      };
    }).filter(region => region.hasMatch);
  }, [searchTerm]);

  return (
    <div className="bg-black min-h-screen pt-24 pb-24">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Hero Section */}
        <div className="mb-20 text-center relative py-20">
          <div className="absolute inset-0 gold-gradient opacity-[0.03] blur-[120px]"></div>
          <div className="relative z-10">
            <span className="text-yellow-500 font-bold uppercase tracking-[0.5em] text-[10px] mb-6 block">Global Presence</span>
            <h1 className="text-5xl md:text-8xl font-serif font-bold text-white mb-8 tracking-tighter">
              Explore Our <br />
              <span className="gold-text-gradient italic">World Directory</span>
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto font-light text-lg md:text-xl leading-relaxed">
              From the vibrant hubs of the Middle East to the historic capitals of Europe, we bridge the gap between you and the world's most exclusive destinations.
            </p>
          </div>
        </div>

        {/* Real-time Global Search */}
        <div className="max-w-3xl mx-auto mb-24 sticky top-24 z-50">
          <div className="bg-zinc-950/90 backdrop-blur-xl p-2 rounded-full border border-yellow-900/30 flex items-center shadow-2xl transition-all focus-within:border-yellow-500/50">
            <div className="flex-shrink-0 pl-6 text-yellow-500">
              <Search size={20} />
            </div>
            <input 
              type="text" 
              placeholder="Search for your next city, country or region..." 
              className="w-full bg-transparent border-none py-4 px-6 text-white focus:outline-none placeholder:text-gray-600 font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button className="hidden md:block btn-gold px-10 py-3.5 rounded-full text-[10px] uppercase font-black tracking-widest mr-1">
              Find Destination
            </button>
          </div>
        </div>

        {/* Regional Sections */}
        <div className="space-y-40">
          {filteredDestinations.length > 0 ? (
            filteredDestinations.map((region, i) => {
              const isSearching = searchTerm.length > 0;
              return (
                <div key={i} className={`group transition-all duration-700 ${isSearching ? 'scale-[1.02]' : ''}`}>
                  <div className="flex flex-col md:flex-row items-start justify-between mb-16 gap-12">
                    <div className="space-y-6 max-w-2xl">
                      <div className="flex items-center gap-3 text-yellow-500">
                        <Globe size={18} />
                        <span className="text-[10px] uppercase font-black tracking-[0.4em]">Regional Hub</span>
                      </div>
                      <h2 className="text-4xl md:text-6xl font-serif font-bold text-white uppercase tracking-tighter flex items-center gap-4">
                        {region.name}
                        {isSearching && <Sparkles size={24} className="text-yellow-500 animate-pulse" />}
                      </h2>
                      <p className="text-gray-400 text-lg font-light leading-relaxed border-l-2 border-yellow-500/20 pl-6 italic">
                        {region.description}
                      </p>
                    </div>
                    <div className="h-px flex-grow mx-12 bg-yellow-900/10 hidden lg:block self-center"></div>
                    <div className="text-gray-500 font-bold uppercase tracking-widest text-[10px] self-end">
                      {region.cities.length} Curated Hubs
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
                    {/* Featured Region Image */}
                    <div className="lg:col-span-1">
                      <div className={`relative h-[400px] md:h-[600px] rounded-[3rem] overflow-hidden border transition-all duration-500 ${isSearching ? 'border-yellow-500/50 shadow-[0_0_50px_-12px_rgba(212,175,55,0.3)]' : 'border-yellow-900/20 shadow-2xl'}`}>
                        <img 
                          src={region.image} 
                          alt={region.name} 
                          className={`w-full h-full object-cover transition-all duration-1000 group-hover:scale-105 ${isSearching ? 'grayscale-0' : 'grayscale group-hover:grayscale-0'}`} 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
                        <div className="absolute bottom-10 left-10">
                          <p className="text-yellow-500 font-black uppercase text-[9px] tracking-[0.3em] mb-2">Signature Portfolio</p>
                          <h3 className="text-3xl font-serif font-bold text-white">Elite Escapes</h3>
                        </div>
                      </div>
                    </div>

                    {/* City Grid */}
                    <div className="lg:col-span-3">
                      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
                        {region.cities.map((city, idx) => {
                          const isMatch = isSearching && (
                            city.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            city.country.toLowerCase().includes(searchTerm.toLowerCase())
                          );
                          return (
                            <div 
                              key={idx} 
                              className={`p-8 bg-zinc-950/50 border rounded-3xl transition-all group/city flex flex-col justify-between aspect-square duration-300 ${isMatch ? 'border-yellow-500 bg-yellow-500/5 -translate-y-2' : 'border-yellow-900/10 hover:border-yellow-500/30 hover:-translate-y-2'}`}
                            >
                              <div>
                                <MapPin size={16} className={`mb-4 transition-opacity ${isMatch ? 'text-yellow-500 opacity-100' : 'text-yellow-500 opacity-50 group-hover/city:opacity-100'}`} />
                                <h4 className={`font-bold text-lg mb-1 leading-tight ${isMatch ? 'text-yellow-500' : 'text-white'}`}>{city.name}</h4>
                                <p className="text-gray-500 text-[10px] uppercase font-bold tracking-widest">{city.country}</p>
                              </div>
                              <div className="flex items-center justify-between pt-6 mt-4 border-t border-yellow-900/5">
                                <span className={`text-[9px] font-black uppercase tracking-tighter ${isMatch ? 'text-yellow-500' : 'text-yellow-500/40'}`}>TF-Premier</span>
                                <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all ${isMatch ? 'bg-yellow-500 text-black border-yellow-500' : 'border-yellow-900/20 text-yellow-500 group-hover/city:bg-yellow-500 group-hover/city:text-black'}`}>
                                  <ArrowUpRight size={14} />
                                </div>
                              </div>
                            </div>
                          );
                        })}
                        
                        {!isSearching && (
                          <div className="p-8 bg-zinc-950/20 border border-dashed border-yellow-900/20 rounded-3xl flex flex-col items-center justify-center text-center group/more cursor-pointer hover:bg-zinc-950/40 transition-all">
                            <Compass size={32} className="text-yellow-900/50 mb-4 group-hover/more:text-yellow-500 transition-colors" />
                            <p className="text-gray-600 text-[10px] font-bold uppercase tracking-widest leading-relaxed">
                              And over <br /><span className="text-yellow-600">4,500+ more</span> <br />global hubs
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-40 text-center">
              <Compass size={64} className="text-yellow-500/20 mx-auto mb-8 animate-spin-slow" />
              <h2 className="text-3xl font-serif font-bold text-white mb-4">No Destinations Found</h2>
              <p className="text-gray-500 max-w-md mx-auto">Our global network is vast, but it seems "{searchTerm}" isn't in our primary directory yet. Speak to our custom travel desk.</p>
              <button onClick={() => setSearchTerm("")} className="mt-8 text-yellow-500 underline uppercase tracking-widest text-[10px] font-black">Clear Search</button>
            </div>
          )}
        </div>

        {/* Global Directory Footer CTA */}
        <section className="mt-40">
          <div className="gold-gradient p-1 rounded-[4rem]">
            <div className="bg-black rounded-[3.9rem] p-16 md:p-32 text-center">
              <div className="max-w-3xl mx-auto">
                <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-8">Can't find your <br /><span className="gold-text-gradient italic">Dream City?</span></h2>
                <p className="text-gray-400 text-lg md:text-xl font-light leading-relaxed mb-12">
                  Our network extends beyond these featured hubs. We provide ground support and private logistics in every major metropolis and remote island luxury retreat.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-6">
                  <a href="tel:+971566286377" className="btn-gold px-12 py-5 rounded-full font-black uppercase tracking-widest text-xs">
                    Contact Global Desk
                  </a>
                  <button className="border border-yellow-500/30 text-yellow-500 hover:bg-yellow-500/5 px-12 py-5 rounded-full font-black uppercase tracking-widest text-xs transition-all">
                    Request Bespoke Itinerary
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

      </div>
      <style>{`
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default DestinationsPage;
