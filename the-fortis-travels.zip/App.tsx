
import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { Phone, Mail, MapPin, CreditCard, Menu, X, Facebook, Instagram, Twitter, ShieldCheck, ArrowRight } from 'lucide-react';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import PaymentPage from './pages/PaymentPage';
import DestinationsPage from './pages/DestinationsPage';
import FlightsPage from './pages/FlightsPage';

const Logo = ({ size = "md", light = false }: { size?: "sm" | "md" | "lg", light?: boolean }) => {
  const sizes = {
    sm: { icon: "w-8 h-8", text: "text-xl", sub: "text-[7px]" },
    md: { icon: "w-10 h-10", text: "text-2xl", sub: "text-[8px]" },
    lg: { icon: "w-16 h-16", text: "text-4xl", sub: "text-[12px]" }
  };

  return (
    <div className="flex items-center gap-3 group cursor-pointer">
      <div className={`${sizes[size].icon} relative flex items-center justify-center transition-transform duration-500 group-hover:rotate-[360deg]`}>
        <div className="absolute inset-0 border border-yellow-500/30 rounded-full"></div>
        <div className="absolute inset-1 border-2 border-yellow-500 rounded-full gold-gradient opacity-20"></div>
        <span className={`font-serif font-bold gold-text-gradient ${size === 'lg' ? 'text-3xl' : 'text-xl'} italic translate-y-[-1px]`}>F</span>
      </div>
      <div className="flex flex-col">
        <span className={`${sizes[size].text} font-serif font-bold leading-none tracking-tighter uppercase ${light ? 'text-white' : 'gold-text-gradient'}`}>
          The Fortis
        </span>
        <span className={`${sizes[size].sub} tracking-[0.5em] text-yellow-500 font-black uppercase mt-1 opacity-80`}>
          Travels & Lifestyle
        </span>
      </div>
    </div>
  );
};

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Flights', path: '/flights' },
    { name: 'Holidays', path: '/destinations' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <nav className={`fixed w-full z-[100] transition-all duration-500 ${
      scrolled ? 'bg-black/95 backdrop-blur-md py-4 border-b border-yellow-900/30' : 'bg-transparent py-8'
    }`}>
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex-shrink-0">
            <Logo size="md" />
          </Link>
          
          <div className="hidden xl:block">
            <div className="flex items-center space-x-10">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`text-gray-300 hover:text-yellow-500 text-[10px] font-black uppercase tracking-[0.2em] transition-all relative group ${
                    location.pathname === link.path ? 'text-yellow-500' : ''
                  }`}
                >
                  {link.name}
                  <span className={`absolute -bottom-2 left-0 w-full h-0.5 bg-yellow-500 transition-transform origin-left ${location.pathname === link.path ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></span>
                </Link>
              ))}
            </div>
          </div>

          <div className="hidden xl:flex items-center space-x-8">
            <div className="flex items-center gap-3 text-white border-r border-yellow-900/30 pr-8">
              <Phone size={14} className="text-yellow-500" />
              <span className="text-[11px] font-black tracking-widest">+971 56 628 6377</span>
            </div>
            <Link to="/payment" className="btn-gold px-8 py-3 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-yellow-500/20">
              <CreditCard size={14} /> Buy Online
            </Link>
          </div>

          <div className="xl:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-yellow-500 hover:text-white p-2">
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="xl:hidden bg-black fixed inset-0 z-[200] overflow-y-auto">
          <div className="p-6 flex flex-col h-full">
            <div className="flex justify-between items-center mb-12">
               <Logo size="md" />
               <button onClick={() => setIsOpen(false)} className="text-yellow-500"><X size={32} /></button>
            </div>
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`py-6 text-3xl font-serif font-bold uppercase border-b border-yellow-900/10 ${
                    location.pathname === link.path ? 'gold-text-gradient' : 'text-gray-300'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              <Link to="/payment" onClick={() => setIsOpen(false)} className="py-8 text-3xl font-serif font-bold uppercase gold-text-gradient flex items-center justify-between">
                Buy Online <CreditCard size={32} />
              </Link>
            </div>
            <div className="mt-auto py-12 space-y-6">
               <div className="flex items-center gap-4 text-yellow-500">
                  <Phone size={24} /> <span className="text-xl font-bold tracking-widest">+971 56 628 6377</span>
               </div>
               <div className="flex items-center gap-4 text-gray-500">
                  <Mail size={24} /> <span className="text-sm font-bold uppercase tracking-widest">OPS@THEFORTISNY.COM</span>
               </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

const Footer = () => {
  return (
    <footer className="bg-black border-t border-yellow-900/30 pt-24 pb-12 relative overflow-hidden">
      <div className="absolute bottom-0 right-0 w-96 h-96 gold-gradient opacity-[0.02] blur-[150px] -mb-48 -mr-48"></div>
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="space-y-8">
            <Logo size="lg" />
            <p className="text-gray-400 text-sm leading-relaxed font-light max-w-xs">
              Crafting legacy in travel and lifestyle management. From the heart of Dubai South Freezone to the most exclusive global destinations.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="w-10 h-10 rounded-full border border-yellow-900/30 flex items-center justify-center text-gray-500 hover:text-yellow-500 hover:border-yellow-500 transition-all"><Facebook size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full border border-yellow-900/30 flex items-center justify-center text-gray-500 hover:text-yellow-500 hover:border-yellow-500 transition-all"><Instagram size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full border border-yellow-900/30 flex items-center justify-center text-gray-500 hover:text-yellow-500 hover:border-yellow-500 transition-all"><Twitter size={18} /></a>
            </div>
          </div>
          <div>
            <h4 className="text-white font-black mb-10 text-[10px] uppercase tracking-[0.3em] flex items-center gap-3">
              <div className="w-8 h-px bg-yellow-500"></div> Our Verticals
            </h4>
            <ul className="space-y-5 text-[10px] text-gray-400 font-black tracking-widest uppercase">
              <li><Link to="/flights" className="hover:text-yellow-500 transition-colors">Global Flight Portal</Link></li>
              <li><Link to="/destinations" className="hover:text-yellow-500 transition-colors">Bespoke Holiday Packages</Link></li>
              <li><Link to="/about" className="hover:text-yellow-500 transition-colors">Corporate Travel Legacy</Link></li>
              <li><Link to="/contact" className="hover:text-yellow-500 transition-colors">Global Support Desk</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-black mb-10 text-[10px] uppercase tracking-[0.3em] flex items-center gap-3">
              <div className="w-8 h-px bg-yellow-500"></div> Head Office
            </h4>
            <ul className="space-y-8 text-gray-400">
              <li className="flex gap-5">
                <MapPin className="text-yellow-500 flex-shrink-0" size={20} />
                <span className="text-[11px] font-bold tracking-widest uppercase leading-loose">
                  THE FORTIS TRAVELS<br/>DUBAI SOUTH FREEZONE<br/>DUBAI, UAE
                </span>
              </li>
              <li className="flex gap-5">
                <Phone className="text-yellow-500 flex-shrink-0" size={20} />
                <span className="text-[11px] font-bold tracking-widest">+971 56 628 6377</span>
              </li>
              <li className="flex gap-5">
                <Mail className="text-yellow-500 flex-shrink-0" size={20} />
                <span className="text-[11px] font-bold tracking-widest uppercase">OPS@THEFORTISNY.COM</span>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-black mb-10 text-[10px] uppercase tracking-[0.3em] flex items-center gap-3">
              <div className="w-8 h-px bg-yellow-500"></div> Newsletter
            </h4>
            <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mb-6">Stay updated on elite destinations</p>
            <div className="flex gap-2">
              <input type="email" placeholder="Email" className="bg-zinc-950 border border-yellow-900/30 rounded-full px-4 py-3 text-[10px] w-full focus:outline-none focus:border-yellow-500" />
              <button className="bg-yellow-500 text-black px-4 rounded-full"><ArrowRight size={16} /></button>
            </div>
          </div>
        </div>
        <div className="border-t border-yellow-900/10 pt-10 flex flex-col md:flex-row justify-between items-center text-[9px] uppercase tracking-[0.4em] text-gray-500 font-black">
          <p>© 2024 THE FORTIS TRAVELS LLC. REGISTERED IN DUBAI SOUTH.</p>
          <div className="flex space-x-8 mt-6 md:mt-0 items-center">
            <span className="text-yellow-600">ENCRYPTED & SECURED</span>
            <ShieldCheck size={20} className="text-yellow-500" />
          </div>
        </div>
      </div>
    </footer>
  );
};

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col selection:bg-yellow-500 selection:text-black">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/flights" element={<FlightsPage />} />
          <Route path="/destinations" element={<DestinationsPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/payment" element={<PaymentPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

export default App;
